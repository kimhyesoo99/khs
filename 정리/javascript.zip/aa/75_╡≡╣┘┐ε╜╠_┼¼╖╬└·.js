'use strict';

const main_container = document.querySelector('.main_container'),
  slide_list = main_container.querySelector('.slide_list'),
  li = slide_list.getElementsByTagName('li'),
  [backBtn, forwardBtn] = main_container.getElementsByTagName('a');

let slide_idx = 0;
/* ================================================================================== */
/* (1) */

// function activeSlide(slideMove, checkIdx, other) {
//   slide_idx += slideMove;
//   slide_list.style.left = `${-slide_idx * 100}%`;

//   other.classList.remove('nonVisible');
//   if (checkIdx()) {
//     this.classList.add('nonVisible');
//   }
// }

// function debounce() {
//   let stopActive;

//   /* 
//   매개변수 없이 arguments로 저장해서 배열로 전달
//   변수에 저장해서 전달해야 됨
//   */
//   const data = arguments;

//   return function () {
//     clearTimeout(stopActive);
//     stopActive = setTimeout(() => activeSlide.apply(this, data), 300); // this는 btn임(맨아래)
//   };
// }

// 지역변수 (stopActive) 유지해주기 위해 변수로 받아놓음
// const clickforwardBtnself = debounce(1, () => slide_idx >= li.length - 1, backBtn);
// const clickBackBtnself = debounce(-1, () => slide_idx <= 0, forwardBtn);

// forwardBtn.addEventListener('click', clickforwardBtnself);
// backBtn.addEventListener('click', clickBackBtnself);
/* ================================================================================== */
/* (2) */

/*
  리턴되는 실제 이벤트 함수에 매개변수를 할당하지 않아도
  arguments 에는 자동으로 이벤트 객체가 저장됨을 확인 가능.

  ※ 여기서 이벤트 발생 주체는 img임
*/
function activeSlide(slideMove, checkIdx, other) {
  const self = this.closest('a');

  if (self) {
    slide_idx += slideMove;
    slide_list.style.left = `${-slide_idx * 100}%`;

    other.classList.remove('nonVisible');
    if (checkIdx()) {
      self.classList.add('nonVisible');
    }
  }
}

function debounce() {
  let stopActive;
  const data = arguments; // 1. 얘랑
  
  
  return function () {
    clearTimeout(stopActive);
    
    stopActive = setTimeout(() => activeSlide.apply(arguments[0].target, data), 300); // 2. 얘랑 다름
  };
}

// // 지역변수 (stopActive) 유지해주기 위해 변수로 받아놓음
// debounce(1, () => slide_idx >= li.length - 1, backBtn);
// debounce(-1, () => slide_idx <= 0, forwardBtn);

// forwardBtn.addEventListener('click', debounce(1, () => slide_idx >= li.length - 1, backBtn));
// backBtn.addEventListener('click', debounce(-1, () => slide_idx <= 0, forwardBtn));

// 지역변수 (stopActive) 유지해주기 위해 변수로 받아놓음
const clickforwardBtnself = debounce(1, () => slide_idx >= li.length - 1, backBtn);
const clickBackBtnself = debounce(-1, () => slide_idx <= 0, forwardBtn);

forwardBtn.addEventListener('click', clickforwardBtnself);
backBtn.addEventListener('click', clickBackBtnself);

/* ================================================================================== */